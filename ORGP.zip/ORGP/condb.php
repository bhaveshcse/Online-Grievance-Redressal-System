<?php
$con=mysqli_connect("localhost","root","","orgp");
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}
?>
