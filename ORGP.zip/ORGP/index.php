<?php 
session_start();
?>
<html lang="en">
<head>
	<title> SRTTC Khamshet| ONLINE GRIEVANCE REDRESSAL PORTAL</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->

<table bgcolor="#107deb" width="100%"><tr>
<td><img src="images/img-01.png" height="100px" width="100px "align="right" alt="IMG"> </td>
<td width="15%"></td>
<td align="center"><font color="White"><h4>Suman Ramesh Tulsiani Technical Campus-Faculty of Engineering</h4></font><font color="yellow"><h5>ONLINE GRIEVANCE REDRESSAL PORTAL</h5></font></td>
<td width="20%"><font color="White" size="1px"><b><blink>Emergency Contact:</b> <br>02114-264101,106</blink></font></td>
</table>
</head>

 <style>
 
		body {
    background-image: url("back.jpg");
}
    </style>

	
	<center>
       <!--- <form class="login100-form validate-form" action="abc.html">
			---><br><br>
			 <form class="login-box" action="" method="get">
			<span class="login100-form-title">
						Member Login
					</span>

					<div class="wrap-input100">
					<i class="fa fa-user icon"></i>
						<input class="input100" type="text" name="uname" placeholder="Enter Username" required>
						<span class="focus-input100"></span>
						<span class="symbol-input100">
						<i class="fa fa-user" aria-hidden="true"></i>
						</span>
					</div>

					<div class="wrap-input100 validate-input" data-validate = "Password is required">
					
						<input class="input100" type="password" name="pwd" placeholder="Enter Password">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-lock" aria-hidden="true"></i>
						</span>
					</div>
					
					<div class="container-login100-form-btn">
						<button name="submit" class="login100-form-btn">
							Login
						</button>
					</div>

					<div class="text-center p-t-12">
											
						<a class="txt2" href="signup.php">
						<center>
							<font color="white" size="2px"><u>Sign Up</u></font></center>
							<i class="fa fa-long-arrow-right m-l-5" aria-hidden="true"></i>
						</a>
					</div>
				</form>
			</div>
		</div>
	</div>
	</center><br>
	
 
	
	

	
<!--===============================================================================================-->	
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/tilt/tilt.jquery.min.js"></script>
	<script >
		$('.js-tilt').tilt({
			scale: 1.1
		})
	</script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>
</html>
<?php
require_once('condb.php');
if(isset($_GET['submit']))
{
$uname=$_GET['uname'];
$_SESSION['uname']=$uname;
$pwd=$_GET['pwd'];
$sql="select * from user where uname='".$uname."' and pwd='".$pwd."'";
$result= $con->query($sql);
if($result->num_rows ==1) {	
$_SESSION["uname"]=$uname;
while($row = $result->fetch_assoc()) {
	if($row['role']=='admin')
	{
	header('location:Home-admin.php');
	}
	else if($row['role']=='principal')
	{	
	header('location:Home-principal.php');
	}
	else if($row['role']=='staff')
	{	
	header('location:Home-staff.php');
	}
	else if($row['role']=='parents')
	{	
	header('location:Home-parents.php');
	}
	else
	{
	header('location:student.php');
	}	
}
}
else{
	?>
	<script>alert('Please enter correct username or password');</script>
<?php	
}
}
?>