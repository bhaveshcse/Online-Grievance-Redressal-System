<html>
<head>
<table bgcolor="#107deb" width="100%">
<tr>
<td><img src="images/img-01.png" height="100px" width="100px "align="right" alt="IMG"> </td>
<td width="15%"></td>
<td align="center"><font color="White"><h4>Suman Ramesh Tulsiani Technical Campus-Faculty of Engineering</h4></font><font color="yellow"><h5>ONLINE GRIEVANCE REDRESSAL PORTAL</h5></font></td>
<td width="20%"><font color="White" size="1px"><b><blink>Emergency Contact:</b> <br>02114-264101,106</blink></font></td>
</tr>
</table>
<style>
.sidenav {
  height: auto;
  width: 0;
  position: fixed;
  z-index: 1;
  top: 30%;
  left: 0;
  background-color: #107deb;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 20px;
}
#login-box {
  top:20%;
  margin: 5% auto;
  width: 60%;
  height: auto;
  background: #ffffff;
  border-radius: 2px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.4);
}
.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 15px;
  color: #ffffff;
  display: block;
  transition: 0.5s;
}

.sidenav a:hover {
  color: red;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 15px;
  font-size: 36px;
  margin-left: 25px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
body{
	background-image: url('back.jpg');
}
</style>
</head>
<body>
<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="#about">Home</a>
  <a href="#summary">Show Summary</a>
  <a href="#">Contact</a>
</div>

<span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; Menu</span>
<script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
</script>
<div id="login-box">
<h3 align="center">Student Panel</h3>
<?php
include_once('condb.php');
$sql="select * from griev where uname='".$uname."'";
$result= $con->query($sql);
if($result->num_rows >0) {
?>	
$i=0;
<table border="1">
<tr>
<td>Sr.No.</td>
<td>Grievance type</td>
<td>Created on</td>
<td>Solved on</td>
<td>Remarks</td>
</tr>
<?php
while($row = $result->fetch_assoc()) {
?>
<tr>
<td><?php echo $i;?></td>
<td><?php $row['gtype'];?></td>
<td><?php $row['cdate'];?></td>
<td><?php $row['sdate'];?></td>
<td><?php $row['remarks'];?></td>
</tr>
<?php
}
}
?>
</table>
</div>
</body>
</html> 